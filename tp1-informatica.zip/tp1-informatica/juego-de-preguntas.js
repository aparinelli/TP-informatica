// Banco de preguntas
const preguntas = [
  {
    texto: "¿Cuál es la capital de Francia?",
    opciones: ["Madrid", "Roma", "París", "Berlín"],
    correcta: 2
  },
  {
    texto: "¿Qué planeta es conocido como el planeta rojo?",
    opciones: ["Júpiter", "Marte", "Venus", "Saturno"],
    correcta: 1
  },
  {
    texto: "¿Quién pintó la Mona Lisa?",
    opciones: ["Van Gogh", "Leonardo da Vinci", "Picasso", "Miguel Ángel"],
    correcta: 1
  },
  {
    texto: "¿Cuál es el océano más grande del mundo?",
    opciones: ["Atlántico", "Índico", "Pacífico", "Ártico"],
    correcta: 2
  }
];

let preguntaActual = 0;
let puntos = 0;
let tiempoRestante = 15;
let timer;

// Elementos del DOM
const textoPregunta = document.getElementById("texto-pregunta");
const botonesOpciones = document.querySelectorAll(".opcion");
const puntosPreguntas = document.getElementById("puntos-preguntas");
const mensaje = document.getElementById("mensaje-preguntas");
const btnSiguiente = document.getElementById("btn-siguiente");
const btnReiniciar = document.getElementById("btn-reiniciar-preguntas");

// Mostrar una pregunta
function mostrarPregunta() {
  clearInterval(timer);
  tiempoRestante = 15;
  iniciarTemporizador();

  const pregunta = preguntas[preguntaActual];
  textoPregunta.textContent = pregunta.texto;
  botonesOpciones.forEach((btn, index) => {
    btn.textContent = pregunta.opciones[index];
    btn.disabled = false;
    btn.classList.remove("correcta", "incorrecta");
    btn.onclick = () => seleccionarRespuesta(index);
  });
  mensaje.textContent = "Selecciona una respuesta...";
}

// Seleccionar respuesta
function seleccionarRespuesta(indice) {
  const pregunta = preguntas[preguntaActual];
  botonesOpciones.forEach(btn => btn.disabled = true);

  if (indice === pregunta.correcta) {
    puntos++;
    puntosPreguntas.textContent = puntos;
    botonesOpciones[indice].classList.add("correcta");
    mensaje.textContent = "¡Correcto!";
  } else {
    botonesOpciones[indice].classList.add("incorrecta");
    botonesOpciones[pregunta.correcta].classList.add("correcta");
    mensaje.textContent = "Respuesta incorrecta.";
  }
  clearInterval(timer);
}

// Siguiente pregunta
btnSiguiente.addEventListener("click", () => {
  preguntaActual++;
  if (preguntaActual < preguntas.length) {
    mostrarPregunta();
  } else {
    textoPregunta.textContent = "¡Juego terminado!";
    mensaje.textContent = `Puntaje final: ${puntos} / ${preguntas.length}`;
    botonesOpciones.forEach(btn => (btn.style.display = "none"));
    clearInterval(timer);
  }
});

// Reiniciar juego
btnReiniciar.addEventListener("click", () => {
  puntos = 0;
  preguntaActual = 0;
  puntosPreguntas.textContent = 0;
  botonesOpciones.forEach(btn => (btn.style.display = "inline-block"));
  mostrarPregunta();
});

// Temporizador
function iniciarTemporizador() {
  timer = setInterval(() => {
    tiempoRestante--;
    mensaje.textContent = `Tiempo restante: ${tiempoRestante}s`;
    if (tiempoRestante <= 0) {
      clearInterval(timer);
      terminarJuego();
    }
  }, 1000);
}

// Función para terminar el juego
function terminarJuego() {
  textoPregunta.textContent = "¡Juego terminado!";
  mensaje.textContent = `Puntaje final: ${puntos} / ${preguntas.length}`;
  botonesOpciones.forEach(btn => (btn.style.display = "none"));
  clearInterval(timer);
}

// Iniciar el juego
mostrarPregunta();

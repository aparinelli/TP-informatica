// Banco de preguntas
const bancoPreguntas = [
  { texto: "¿Cuál es la capital de Francia?", opciones: ["Madrid", "Roma", "París", "Berlín"], correcta: 2 },
  { texto: "¿Qué planeta es conocido como el planeta rojo?", opciones: ["Júpiter", "Marte", "Venus", "Saturno"], correcta: 1 },
  { texto: "¿Quién pintó la Mona Lisa?", opciones: ["Van Gogh", "Leonardo da Vinci", "Picasso", "Miguel Ángel"], correcta: 1 },
  { texto: "¿Cuál es el océano más grande del mundo?", opciones: ["Atlántico", "Índico", "Pacífico", "Ártico"], correcta: 2 },
  { texto: "¿Cuál es el país más grande del mundo?", opciones: ["Canadá", "China", "Estados Unidos", "Rusia"], correcta: 3 },
  { texto: "¿Qué gas respiramos para vivir?", opciones: ["Dióxido de carbono", "Oxígeno", "Nitrógeno", "Hidrógeno"], correcta: 1 },
  { texto: "¿Cuántos días tiene un año bisiesto?", opciones: ["365", "366", "364", "360"], correcta: 1 },
  { texto: "¿Cuál es el río más largo del mundo?", opciones: ["Amazonas", "Nilo", "Yangtsé", "Misisipi"], correcta: 0 },
  { texto: "¿Cuál flor sigue al sol?", opciones: ["Hortensia", "Margarita", "Girasol", "Loto"], correcta: 2 },
  { texto: "¿Cuál ave no puede volar?", opciones: ["Paloma", "Pinguino", "Cuervo", "Loro"], correcta: 1 },
  { texto: "¿Cuál es la flor nacional de Argentina?", opciones: ["Jacaranda", "Diente de leon", "Jasmin", "Ceibo"], correcta: 3 },
  { texto: "Rojo + azul da...", opciones: ["Verde", "Violeta", "Amarillo", "Naranja"], correcta: 1 },
  { texto: "¿Cuantos colores tiene la bandera de Argentina?", opciones: ["2", "4", "1", "3"], correcta: 3 },
  { texto: "¿Que equipo de fútbol es amarillo y azul?", opciones: ["All boys", "River", "Boca", "Velez"], correcta: 2 },
  { texto: "¿Que animal maulla?", opciones: ["Gato", "Perro", "Hamster", "Loro"], correcta: 0 },
  { texto: "¿Que colores crean rosa?", opciones: ["Blanco + rojo", "Amarillo + violeta", "Naranja + rojo", "Blanco + verde"], correcta: 0 }
];

// Selección aleatoria de 4 preguntas
function obtenerPreguntasAleatorias(banco, cantidad) {
  const copia = [...banco];
  const seleccionadas = [];
  while (seleccionadas.length < cantidad && copia.length > 0) {
    const indice = Math.floor(Math.random() * copia.length);
    seleccionadas.push(copia.splice(indice, 1)[0]);
  }
  return seleccionadas;
}

// Solo 4 preguntas por partida
let preguntas = obtenerPreguntasAleatorias(bancoPreguntas, 4);

let preguntaActual = 0;
let puntos = 0;
let tiempoRestante = 15;
let timer;

// Elementos del DOM
const textoPregunta = document.getElementById("texto-pregunta");
const botonesOpciones = document.querySelectorAll(".opcion");
const puntosPreguntas = document.getElementById("puntos-preguntas");
const mensaje = document.getElementById("mensaje-preguntas");
const btnSiguiente = document.getElementById("btn-siguiente");
const btnReiniciar = document.getElementById("btn-reiniciar-preguntas");

// --- Estilos iniciales de botones ---
btnSiguiente.disabled = true;
btnSiguiente.style.backgroundColor = "gray";
btnReiniciar.style.opacity = "0.6";

// Mostrar una pregunta
function mostrarPregunta() {
  clearInterval(timer);
  tiempoRestante = 15;
  iniciarTemporizador();

  // Botón siguiente vuelve a desactivarse
  btnSiguiente.disabled = true;
  btnSiguiente.style.backgroundColor = "gray";

  const pregunta = preguntas[preguntaActual];
  textoPregunta.textContent = pregunta.texto;
  botonesOpciones.forEach((btn, index) => {
    btn.textContent = pregunta.opciones[index];
    btn.disabled = false;
    btn.classList.remove("correcta", "incorrecta");
    btn.onclick = () => seleccionarRespuesta(index);
  });
  mensaje.textContent = "Selecciona una respuesta...";
}

// Seleccionar respuesta
function seleccionarRespuesta(indice) {
  const pregunta = preguntas[preguntaActual];
  botonesOpciones.forEach(btn => btn.disabled = true);

  if (indice === pregunta.correcta) {
    puntos++;
    puntosPreguntas.textContent = puntos;
    botonesOpciones[indice].classList.add("correcta");
    mensaje.textContent = "¡Correcto!";
  } else {
    botonesOpciones[indice].classList.add("incorrecta");
    botonesOpciones[pregunta.correcta].classList.add("correcta");
    mensaje.textContent = "Respuesta incorrecta.";
  }

  clearInterval(timer);

  // ✅ Activar botón siguiente con color amarillo
  btnSiguiente.disabled = false;
  btnSiguiente.style.backgroundColor = "gold";
}

// Siguiente pregunta
btnSiguiente.addEventListener("click", () => {
  preguntaActual++;
  if (preguntaActual < preguntas.length) {
    mostrarPregunta();
  } else {
    terminarJuego();
  }
});

// Reiniciar juego
btnReiniciar.addEventListener("click", () => {
  puntos = 0;
  preguntaActual = 0;
  puntosPreguntas.textContent = 0;
  botonesOpciones.forEach(btn => (btn.style.display = "inline-block"));
  btnReiniciar.style.backgroundColor = "";
  btnReiniciar.style.opacity = "0.6";
  btnSiguiente.style.display = "inline-block";
  mostrarPregunta();
});

// Temporizador
function iniciarTemporizador() {
  timer = setInterval(() => {
    tiempoRestante--;
    mensaje.textContent = `Tiempo restante: ${tiempoRestante}s`;
    if (tiempoRestante <= 0) {
      clearInterval(timer);
      terminarJuego();
    }
  }, 1000);
}

// Función para terminar el juego
function terminarJuego() {
  textoPregunta.textContent = "¡Juego terminado!";
  mensaje.textContent = `Puntaje final: ${puntos} / ${preguntas.length}`;
  botonesOpciones.forEach(btn => (btn.style.display = "none"));
  clearInterval(timer);

  // Muestra reiniciar con color amarillo
  btnReiniciar.style.opacity = "1";
  btnReiniciar.style.backgroundColor = "#ffd54f";

  // Oculta el botón de siguiente
  btnSiguiente.style.display = "none";
}

// Iniciar el juego
mostrarPregunta();

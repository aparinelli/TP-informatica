// --- tabla-de-puntajes.js ---

// Obtener los puntajes guardados en localStorage (o poner 0 si no existen)
const puntajeCartas = localStorage.getItem("puntosCartas") || 0;
const puntajeDados = localStorage.getItem("puntosDados") || 0;
const puntajePreguntas = localStorage.getItem("puntosPreguntas") || 0;

// Seleccionar todas las filas de usuarios (excluyendo el encabezado)
const filas = document.querySelectorAll(".scoreboard .row:not(.header)");

// Asigna los mismos puntajes a todos
// (luego puedes adaptarlo para tener varios usuarios)
filas.forEach((fila, i) => {
  const celdas = fila.querySelectorAll(".cell");
  celdas[1].textContent = puntajeCartas;
  celdas[2].textContent = puntajeDados;
  celdas[3].textContent = puntajePreguntas;
});

// --- Extra: limpiar puntajes si lo necesitas ---
// localStorage.clear();
localStorage.setItem("puntosCartas", puntos);
localStorage.setItem("puntosDados", puntos);
localStorage.setItem("puntosPreguntas", puntos);
